﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        double Suma(double x, double y, double z)
        {
            double suma;
            suma = (1 + Math.Sin(x + y) / Math.Abs(x - (2 * x / 1 + Math.Pow(x, 2) * Math.Pow(y, 2)))) * Math.Pow(x, Math.Abs(y)) + Math.Tan(1 / z);
            return Math.Round(suma, 3);
        }
        public MainWindow()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double x, y, z;
            x = Convert.ToDouble(textBox1.Text);
            y = Convert.ToDouble(textBox2.Text);
            z = Convert.ToDouble(textBox3.Text);

            double r = Suma(x, y, z);

            textBox4.Text = r.ToString();
        }
    }
}
