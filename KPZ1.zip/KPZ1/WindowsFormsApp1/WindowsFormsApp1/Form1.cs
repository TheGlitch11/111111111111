﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        double Suma(double x, double y, double z)
        {
            double suma;
            suma = (1 + Math.Sin(x + y) / Math.Abs(x - (2 * x / 1 + Math.Pow(x, 2) * Math.Pow(y, 2)))) * Math.Pow(x, Math.Abs(y)) + Math.Tan(1 / z);
            return Math.Round(suma, 3);
        }
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double x, y, z;
            x = Convert.ToDouble(textBox1.Text);
            y = Convert.ToDouble(textBox2.Text);
            z = Convert.ToDouble(textBox3.Text);

            double r = Suma(x, y, z);

            textBox4.Text = r.ToString();
        }
    }
}
