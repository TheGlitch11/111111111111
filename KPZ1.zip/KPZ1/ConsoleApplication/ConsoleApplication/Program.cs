﻿using System;

namespace ConsoleApplication
{
    class Program
    {
        static void getSuma(double suma)
        {
            Console.WriteLine($"\nСума цих даних {suma}");
        }
        static double Suma(double x, double y, double z)
        {
            double suma;
            suma = (1 + Math.Sin(x + y) / Math.Abs(x - (2 * x / 1 + Math.Pow(x, 2) * Math.Pow(y, 2)))) * Math.Pow(x, Math.Abs(y)) + Math.Tan(1 / z);
            return Math.Round(suma, 3);
        }
        static void Main(string[] args)
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;
            double x, y, z;
            Console.WriteLine("П-41 Куничак Ростислав'\n Варіант 10\n\n");
            Console.WriteLine("Введіть значення X:\n");
            x = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("\nВведіть значення Y:\n");
            y = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("\nВведіть значення Z:\n");
            z = Convert.ToDouble(Console.ReadLine());
            getSuma(Suma(x, y, z));
        }
    }
}